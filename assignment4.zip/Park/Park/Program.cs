﻿class Program
{
    static void Main(string[] args)
    {
        // Create a Park object for Pukaskwa
        Park pukaskwaPark = new Park("Pukaskwa", "Northern Ontario", "National", "camping, beaches and canoe launch", 6.5, 50, 20000, 50000);

        Console.WriteLine("Pukaskwa Park Information: " + pukaskwaPark.ParkInformation());
        Console.WriteLine("Pukaskwa Park Facilities Information: " + pukaskwaPark.FacilitiesInformation());
        Console.WriteLine($"Pukaskwa Park Cost per Visitor: {pukaskwaPark.ComputeCostPerVisitor():C}");
        Console.WriteLine($"Pukaskwa Park Revenue from Fees: {pukaskwaPark.ComputeRevenueFromFees():C}");
        Console.WriteLine();

        Console.WriteLine("Pukaskwa Park All Data:");
        Console.WriteLine(pukaskwaPark.ToString());
        Console.WriteLine();

        // Create a Park object for Elk Island National Park
        Park elkIslandPark = new Park("Elk Island Park", "Alberta", "National", 9);
        Console.WriteLine("Elk Island Park Information: " + elkIslandPark.ParkInformation());
        Console.WriteLine();

        // Create a Park object for Banff Park
        Park banffPark = new Park("Banff Park", "Alberta", "National", "hiking trails, camping, wildlife viewing", 11);
        Console.WriteLine("Banff Park Information: " + banffPark.ParkInformation());
        Console.WriteLine("Banff Park Facilities Information: " + banffPark.FacilitiesInformation());
        Console.WriteLine();

        Console.ReadKey();
    }
}