﻿/*using static System.Net.Mime.MediaTypeNames;

There are several national and state parks available to tourists. 
1. Create a Park class. Include data members such as name of park, location, type of (i.e., national, state, and local) facility, fee, number of employees, number of visitors recorded for the past 12 months, and annual budget.
2. Write separate instance methods that 
(1) return a string representing name of the park, the location, and type of park. 
(2) return a string representing the name of the park, the location, and facilities available. 
(3) compute cost per visitor based on annual budget and the number of visitors during the last 12 months; and
(4) compute revenue from fees for the past year based on number of visitors and fee. Also include a ToString( ) method that returns all data members with appropriate labels. 

Create a second class to test your Park class.*/





using System;

public class Park
{
    private string name;
    private string location;
    private string parkType;
    private string facilities;
    private double fee;
    private int numberOfEmployees;
    private int visitorsLast12Months;
    private double annualBudget;

    public string Name
    {
        get { return name; }
        set { name = value; }
    }

    public string Location
    {
        get { return location; }
        set { location = value; }
    }

    public string ParkType
    {
        get { return parkType; }
        set { parkType = value; }
    }

    public string Facilities
    {
        get { return facilities; }
        set { facilities = value; }
    }

    public double Fee
    {
        get { return fee; }
        set { fee = value; }
    }

    public int NumberOfEmployees
    {
        get { return numberOfEmployees; }
        set { numberOfEmployees = value; }
    }

    public int VisitorsLast12Months
    {
        get { return visitorsLast12Months; }
        set { visitorsLast12Months = value; }
    }

    public double AnnualBudget
    {
        get { return annualBudget; }
        set { annualBudget = value; }
    }

    // Constructor for Pukaskwa Park
    public Park(string name, string location, string parkType, string facilities, double fee, int numberOfEmployees, int visitorsLast12Months, double annualBudget)
    {
        Name = name;
        Location = location;
        ParkType = parkType;
        Facilities = facilities;
        Fee = fee;
        NumberOfEmployees = numberOfEmployees;
        VisitorsLast12Months = visitorsLast12Months;
        AnnualBudget = annualBudget;
    }

    // Constructor for Elk Island National Park
    public Park(string name, string location, string parkType, double fee)
    {
        Name = name;
        Location = location;
        ParkType = parkType;
        Fee = fee;

    }

    // Constructor for Banff Park
    public Park(string name, string location, string parkType, string facilities, double fee)
    {
        Name = name;
        Location = location;
        ParkType = parkType;
        Facilities = facilities;
        Fee = fee;
    }



    // Method to return a string representing park name, location, and type
    public string ParkInformation()
    {
        return $"{Name} in {Location} is a {ParkType} park.";
    }

    // Method to return a string representing park name, location, and facilities available
    public string FacilitiesInformation()
    {
        return $"{Name} in {Location} offers facilities such as {Facilities}.";
    }

    // Method to compute cost per visitor based on annual budget and number of visitors
    public double ComputeCostPerVisitor()
    {

        return AnnualBudget / VisitorsLast12Months;
    }

    // Method to compute revenue from fees for the past year based on number of visitors and fee
    public double ComputeRevenueFromFees()
    {
        return VisitorsLast12Months * Fee;
    }

    // ToString method to return all data members with appropriate labels
    public override string ToString()
    {
        return $"Park Name: {Name}\nLocation: {Location}\nType: {ParkType}\nFacilities: {Facilities}\nFee: {Fee:C}\nNumber of Employees: {NumberOfEmployees}\nVisitors Last 12 Months: {VisitorsLast12Months}\nAnnual Budget: {AnnualBudget:C}";
    }
}