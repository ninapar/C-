﻿/*Write a program that computes a weighted average giving the following weights.
•	Homework: 10%
•	Projects: 35%
•	Quizzes: 10%
•	Exams: 30%
•	Final Exam: 15%

Do a compile-time initialization with the following values:

Homework: 97; Projects: 82; Quizzes: 60; Exams: 75; Final Exam 80.

Display all values, including the weights, appropriately labeled, and formatted. 

Rerun the application with different values.
*/

using System;

class Program
{
    static void Main(string[] args)
    {
        const double HOMEWORK = 0.10;
        const double PROJECTS = 0.35;
        const double QUIZZES = 0.10;
        const double EXAMS = 0.30;
        const double FINAL = 0.15;

        int homeworkAverage = 97;
        int projectAverage = 82;
        int quizAverage = 60;
        int examAverage = 75;
        int finalExam = 80;

        double overallAverage;

        overallAverage = homeworkAverage * HOMEWORK + projectAverage * PROJECTS + quizAverage * QUIZZES + examAverage * EXAMS + finalExam * FINAL;

        Console.WriteLine("Weighted Average Calculation");
        Console.WriteLine("");
        Console.WriteLine($"{"Homework:",-15}{HOMEWORK:P0} ({homeworkAverage})");
        Console.WriteLine($"{"Projects:",-15}{PROJECTS:P0} ({projectAverage})");
        Console.WriteLine($"{"Quizzes:",-15}{QUIZZES:P0} ({quizAverage})");
        Console.WriteLine($"{"Exams:",-15}{EXAMS:P0} ({examAverage})");
        Console.WriteLine($"{"Final Exam:",-15}{FINAL:P0} ({finalExam})");
        Console.WriteLine("--------------------------------------------");
        Console.WriteLine($"{"Average:",-15}{overallAverage:F2}");


        Console.ReadLine();
    }
}

