﻿using System;

class Program
{
    static void Main(string[] args)
    {

        Console.Write("Enter employee's name: ");
        string name = Console.ReadLine();


        Console.Write("Enter weekly sales amount: ");
        double salesAmount;
        while (!double.TryParse(Console.ReadLine(), out salesAmount))
        {
            Console.WriteLine("Invalid input. Please enter a valid number for sales amount.");
            Console.Write("Enter weekly sales amount: ");
        }


        Console.Write("Enter employee number: ");
        int employeeNumber;
        while (!int.TryParse(Console.ReadLine(), out employeeNumber))
        {
            Console.WriteLine("Invalid input. Please enter a valid number for employee number.");
            Console.Write("Enter employee number: ");
        }


        Console.Write("Enter hire date (MM/DD/YYYY): ");
        DateTime hireDate;
        while (!DateTime.TryParseExact(Console.ReadLine(), "MM/dd/yyyy", null, System.Globalization.DateTimeStyles.None, out hireDate))
        {
            Console.WriteLine("Invalid input. Please enter a valid date in MM/DD/YYYY format.");
            Console.Write("Enter hire date (MM/DD/YYYY): ");
        }

        // Create Employee object for the input
        Employee employee = new Employee(name, salesAmount, employeeNumber, hireDate);

        // Display information for Employee
        Console.WriteLine("\nEmployee (All Parameters):");
        Console.WriteLine($"Name: {employee.Name}");
        Console.WriteLine($"Sales Amount: {employee.SalesAmount:C2}");
        Console.WriteLine($"Employee Number: {employee.EmployeeNumber}");
        Console.WriteLine($"Hire Date: {employee.HireDate.ToShortDateString()}");
        Console.WriteLine($"Commission Income: {employee.CalculateCommissionIncome():C2}");
        Console.WriteLine($"Federal Tax: {employee.CalculateFederalTax():C2}");
        Console.WriteLine($"Social Security Tax: {employee.CalculateSocialSecurityTax():C2}");
        Console.WriteLine($"Retirement Contribution: {employee.CalculateRetirementContribution():C2}");
        Console.WriteLine($"Take-Home Pay: {employee.CalculateTakeHomePay():C2}");

        // Create Employee objects using different constructors
        Employee employee1 = new Employee();  // Default constructor (no arguments)
        Employee employee2 = new Employee("Sophie Soto");  // Constructor with name parameter
        Employee employee3 = new Employee("Alice Fillion", 2000.00);  // Constructor with name and sales amount parameters
        Employee employee4 = new Employee("Brenda Mitch", 3000.00, 112);  // Constructor with name, sales amount, and employee number parameters
        Employee employee5 = new Employee("Justin Harvey", 2500.00, 114, DateTime.Parse("2023-03-15"));  // Constructor with name, sales amount, employee number, and hire date parameters

        // Display information for other employees
        Console.WriteLine("\nEmployee 1 (Default Constructor - No Arguments):");
        Console.WriteLine($"Name: {employee1.Name}");

        Console.WriteLine("\nEmployee 2 (Name Parameter):");
        Console.WriteLine($"Name: {employee2.Name}");

        Console.WriteLine("\nEmployee 3 (Name and Sales Amount):");
        Console.WriteLine($"Name: {employee3.Name}");
        Console.WriteLine($"Sales Amount: {employee3.SalesAmount:C2}");
        Console.WriteLine($"Commission Income: {employee3.CalculateCommissionIncome():C2}");
        Console.WriteLine($"Federal Tax: {employee3.CalculateFederalTax():C2}");
        Console.WriteLine($"Social Security Tax: {employee3.CalculateSocialSecurityTax():C2}");
        Console.WriteLine($"Retirement Contribution: {employee3.CalculateRetirementContribution():C2}");
        Console.WriteLine($"Take-Home Pay: {employee3.CalculateTakeHomePay():C2}");

        Console.WriteLine("\nEmployee 4 (Name, Sales Amount and Employee Number):");
        Console.WriteLine($"Name: {employee4.Name}");
        Console.WriteLine($"Sales Amount: {employee4.SalesAmount:C2}");
        Console.WriteLine($"Employee Number: {employee4.EmployeeNumber}");
        Console.WriteLine($"Commission Income: {employee4.CalculateCommissionIncome():C2}");
        Console.WriteLine($"Federal Tax: {employee4.CalculateFederalTax():C2}");
        Console.WriteLine($"Social Security Tax: {employee4.CalculateSocialSecurityTax():C2}");
        Console.WriteLine($"Retirement Contribution: {employee4.CalculateRetirementContribution():C2}");
        Console.WriteLine($"Take-Home Pay: {employee4.CalculateTakeHomePay():C2}");

        Console.WriteLine("\nEmployee 5 (Name, Sales Amount, Employee Number, and Hire Date Parameters):");
        Console.WriteLine($"Name: {employee5.Name}");
        Console.WriteLine($"Sales Amount: {employee5.SalesAmount:C2}");
        Console.WriteLine($"Employee Number: {employee5.EmployeeNumber}");
        Console.WriteLine($"Hire Date: {employee5.HireDate.ToShortDateString()}");
        Console.WriteLine($"Commission Income: {employee5.CalculateCommissionIncome():C2}");
        Console.WriteLine($"Federal Tax: {employee5.CalculateFederalTax():C2}");
        Console.WriteLine($"Social Security Tax: {employee5.CalculateSocialSecurityTax():C2}");
        Console.WriteLine($"Retirement Contribution: {employee5.CalculateRetirementContribution():C2}");
        Console.WriteLine($"Take-Home Pay: {employee5.CalculateTakeHomePay():C2}");

        Console.ReadKey();
    }
}
