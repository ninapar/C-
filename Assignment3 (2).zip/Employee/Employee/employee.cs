﻿/*Write a program that includes an Employee class that can be used to calculate and print the take-home pay for a commissioned sales employee. 
1. All employees receive 7% of the total sales. 
2. Federal tax rate is 18%. Retirement contribution is 10%. 
3. Social Security tax rate is 6%.

Write instance methods to calculate the commission income, federal and social security tax withholding amounts and the amount withheld for retirement. Use appropriate constants, design an object-oriented solution, and write constructors. 
Create a second class to test your design. Allow the user to enter values for the name of the employee and the sales amount for the week in the second class.
Bonus: 
Include one mutator and one accessor method and provide properties for the other instance variables. 

*/
using System;

class Employee
{
    // Properties
    public string Name { get; set; }
    public double SalesAmount { get; set; }
    public int EmployeeNumber { get; set; }
    public DateTime HireDate { get; set; }

    // Constants for tax rates and contribution percentages
    private const double COMMISSION_RATE = 0.07;
    private const double FEDERAL_TAX_RATE = 0.18;
    private const double RETIREMENT_CONTRIBUTION_RATE = 0.10;
    private const double SOCIAL_SECURITY_TAX_RATE = 0.06;

    // Default constructor
    public Employee()
    {
    }

    // Constructor with name parameter
    public Employee(string name)
    {
        Name = name;
    }

    // Constructor with name and sales amount parameters
    public Employee(string name, double salesAmount)
    {
        Name = name;
        SalesAmount = salesAmount;
    }

    // Constructor with name, sales amount, and employee number parameters
    public Employee(string name, double salesAmount, int employeeNumber)
    {
        Name = name;
        SalesAmount = salesAmount;
        EmployeeNumber = employeeNumber;
    }

    // Constructor with name, sales amount, employee number, and hire date parameters
    public Employee(string name, double salesAmount, int employeeNumber, DateTime hireDate)
    {
        Name = name;
        SalesAmount = salesAmount;
        EmployeeNumber = employeeNumber;
        HireDate = hireDate;
    }

    // Method to calculate commission income
    public double CalculateCommissionIncome()
    {
        return SalesAmount * COMMISSION_RATE;
    }

    // Method to calculate federal tax withholding
    public double CalculateFederalTax()
    {
        return SalesAmount * COMMISSION_RATE * FEDERAL_TAX_RATE;
    }

    // Method to calculate social security tax withholding
    public double CalculateSocialSecurityTax()
    {
        return SalesAmount * COMMISSION_RATE * SOCIAL_SECURITY_TAX_RATE;
    }

    // Method to calculate retirement contribution withholding
    public double CalculateRetirementContribution()
    {
        return SalesAmount * COMMISSION_RATE * RETIREMENT_CONTRIBUTION_RATE;
    }

    // Method to calculate take-home pay
    public double CalculateTakeHomePay()
    {
        return SalesAmount * COMMISSION_RATE - CalculateFederalTax() - CalculateSocialSecurityTax() - CalculateRetirementContribution();
    }
}
